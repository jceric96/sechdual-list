-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 21, 2021 at 04:58 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `2170`
--
CREATE DATABASE IF NOT EXISTS `2170` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `2170`;

-- --------------------------------------------------------

--
-- Table structure for table `mylist`
--

DROP TABLE IF EXISTS `mylist`;
CREATE TABLE `mylist` (
  `l_id` int(11) NOT NULL,
  `l_item` varchar(128) NOT NULL,
  `l_done` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mylist_login`
--

DROP TABLE IF EXISTS `mylist_login`;
CREATE TABLE `mylist_login` (
  `m_login_id` int(11) NOT NULL,
  `m_login_username` varchar(128) NOT NULL,
  `m_login_password` varchar(256) NOT NULL,
  `m_login_firstname` varchar(128) NOT NULL,
  `m_login_lastname` varchar(128) NOT NULL,
  `m_login_email` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mylist_login`
--

INSERT INTO `mylist_login` (`m_login_id`, `m_login_username`, `m_login_password`, `m_login_firstname`, `m_login_lastname`, `m_login_email`) VALUES
(1, 'yodaiam', 'doORdonotNOTRY', 'Yoda', '', 'yoda@theforce.org'),
(2, 'rey', 'balance', 'Rey', 'Skywalker', 'reys@theforce.org');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mylist`
--
ALTER TABLE `mylist`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `mylist_login`
--
ALTER TABLE `mylist_login`
  ADD PRIMARY KEY (`m_login_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mylist`
--
ALTER TABLE `mylist`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mylist_login`
--
ALTER TABLE `mylist_login`
  MODIFY `m_login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;